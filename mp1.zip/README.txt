Group Members:
Steven Ge , yge4
John Chmilar , jechmila

Collaborated:
I did not collaborate with anyone else.

Source of information:
stackoverflow.com
google.com

